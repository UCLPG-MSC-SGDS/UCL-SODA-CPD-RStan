
# This script executes the following:
## 1.) Prepares the infestation data to be compiled in Stan interfaced with R 
## 2.) Calls the posterior samples from Stan after compilation 
## 3.) Summarises the posterior samples to get result outputs
## 4.) Produces temporal results for updating

# EXCERPT

rm(list = ls())
gc()

# Load the packages
library("sf")
library("sp")
library("spdep")
library("tmap")
library("geostan")
library("INLA")
library("SpatialEpi")
library("rstan")
library("tidybayes")
library("tidyverse")

# use the full 6 cores on mac-mini desktop for parallel processing
options(mc.cores = parallel::detectCores())
rstan_options(auto_write = TRUE)

# set directory
setwd("~Extra")
# import analysis dataset
infestation_data = read.csv("Example Data for Updating.csv")

# data preparation and set-up for Bayesian analysis in Stan
# sort the data out by individual and group as it was mixed-up 
infestation_data <- infestation_data[order(infestation_data$Individual, infestation_data$Group),]
	rownames(infestation_data) <- 1:nrow(infestation_data)
	colnames(infestation_data)[2] <- "NeighbNum"
	colnames(infestation_data)[3] <- "LIRAaNum"

# load shapefile
campina_grande_neighbourhoods <- read_sf("Campina_Grande_Neighbourhoods.shp")
# remove redundant column 'Total'
campina_grande_neighbourhoods <- campina_grande_neighbourhoods[,-3]
# FML, create an order ID so there harmony with Stan and RStudio
campina_grande_neighbourhoods$OrderName <- 1:47
	OrderInfo <- st_drop_geometry(campina_grande_neighbourhoods[,c(1,4)])
	campina_grande_neighbourhoods <- campina_grande_neighbourhoods[,c(1,4,2,3)]
# align order details in shapefile to infestation data
infestation_data <- merge(infestation_data, OrderInfo, by.x = "osmID", by.y = "osmID")
	infestation_data <- infestation_data[order(infestation_data$OrderName, infestation_data$LIRAaNum),]
	infestation_data$NeighbNum <- infestation_data$OrderName
	infestation_data <- infestation_data[,-16]
	rownames(infestation_data) <- 1:nrow(infestation_data)
# row data in infestation_data object is in perfect alignment with rows in shapefile

# calculate expected numbers
infestation_data$Expected <- round(expected(population = infestation_data$Total, cases = infestation_data$InfestedNum, n.strata = 1), 0)
# need to be coerced into a spatial object
campina_grande_neighb_spobject <- as(campina_grande_neighbourhoods, "Spatial")
# needs to be coerced into a matrix object
adjacencyMatrix <- shape2mat(campina_grande_neighb_spobject)
# we extract the components for the ICAR model
extractComponents <- prep_icar_data(adjacencyMatrix)
	n <- as.numeric(extractComponents$group_size)
	nod1 <- extractComponents$node1
	nod2 <- extractComponents$node2
	n_edges <- as.numeric(extractComponents$n_edges)

adj.matrix=sparseMatrix(i=nod1,j=nod2,x=1,symmetric=TRUE)
Q=Diagonal(n, rowSums(adj.matrix)) - adj.matrix
Q_pert=Q+Diagonal(n) * max(diag(Q)) * sqrt(.Machine$double.eps)
Q_inv=inla.qinv(Q_pert, constr=list(A = matrix(1,1,n),e=0))
scaling_factor=exp(mean(log(diag(Q_inv))))

# use a stratified analysis framework

# 2016 = 1, 2, 3

Lira2016_1 <- infestation_data[infestation_data$LIRAa==1,]
Lira2016_2 <- infestation_data[infestation_data$LIRAa==2,]
Lira2016_3 <- infestation_data[infestation_data$LIRAa==3,]

row.names(Lira2016_1) <- 1:nrow(Lira2016_1)
row.names(Lira2016_2) <- 1:nrow(Lira2016_2)
row.names(Lira2016_3) <- 1:nrow(Lira2016_3)


# STARTING WITH INITIAL BAYESIAN ANALYSIS
# 2016 LIRAa 1
y=Lira2016_1$InfestedNum
x=Lira2016_1[,c(11,12,13,15)] # NDVI, TEMP, PREC, Urbanisation
e=Lira2016_1$Expected

stan.dataset=list(N=n, N_edges=n_edges, node1=nod1, node2=nod2, 
	Y=y, X=x, K=length(x), Offset=e, factor=scaling_factor)

# RUN: multivariable Spatial ICAR Poisson model for 2016 LIRAa 1

# Start the clock and time duration
ptm <- proc.time()
# compiles Bayesian model externally in Stan (see script: "Part 4 - Stan script for executing risk model.stan")
Bayesian.model = stan("Stan script for executing risk model.stan", 
	data=stan.dataset, iter=10000, chains=6, verbose = FALSE, seed = 72182605)
# Stop the clock and report duration
proc.time() - ptm
######################################################################################

# remove that annoying scientific notation
options(scipen = 999)
summary(Bayesian.model, pars=c("alpha", "beta", "sigma", "logit_rho"), probs=c(0.025, 0.975))$summary
summary(Bayesian.model, pars=c("rr_alpha", "rr_beta", "sigma", "logit_rho"), probs=c(0.025, 0.975))$summary

# Posterior sample for our parameter retained in `Bayesian.model` output
######################################################################################

# 1st UPDATING
# REPEAT
#### 2016 LIRAa 2
y=Lira2016_2$InfestedNum
x=Lira2016_2[,c(11,12,13,15)]
e=Lira2016_2$Expected

stan.dataset.2016_2=list(N=n, N_edges=n_edges, node1=nod1, node2=nod2, 
	Y=y, X=x, K=length(x), Offset=e, factor=scaling_factor)

# RUN: multivariable Spatial ICAR Poisson model for 2016 LIRAa 2
# Updated model with new data from 2016 LIRAa 2 survey

# We use the `fit` argument instead of re-running the script

# Start the clock and time duration
ptm <- proc.time()
# Updated Bayesian model
Bayesian.model.2016.2 = stan(fit=Bayesian.model, data=stan.dataset.2016_2,
	iter=60000, chains=6, verbose = FALSE, seed = 72182605)
# Stop the clock and report duration
proc.time() - ptm

# RUN: Source file:
# source("Source file - 2016 LIRAa 2.R")
######################################################################################

# 2nd UPDATING
# REPEAT
#### 2016 LIRAa 3
y=Lira2016_3$InfestedNum
x=Lira2016_3[,c(11,12,13,15)]
e=Lira2016_3$Expected

stan.dataset.2016_3=list(N=n, N_edges=n_edges, node1=nod1, node2=nod2, 
	Y=y, X=x, K=length(x), Offset=e, factor=scaling_factor)

# RUN: multivariable Spatial ICAR Poisson model for 2016 LIRAa 3
# Updated model with new data from 2016 LIRAa 3 survey

# Start the clock and time duration
ptm <- proc.time()
# Updated Bayesian model
Bayesian.model.2016.3 = stan(fit=Bayesian.model.2016.2, data=stan.dataset.2016_3,
	iter=60000, chains=6, verbose = FALSE, seed = 72182605)
# Stop the clock and report duration
proc.time() - ptm

# RUN: Source file:
# source("Source file - 2016 LIRAa 3.R")
######################################################################################